/** Automatically generated file. DO NOT MODIFY */
package jp.megachips.frizzservice;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}